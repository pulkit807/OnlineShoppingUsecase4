package com.usecase.onlineshopping.api.sos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingAppApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
